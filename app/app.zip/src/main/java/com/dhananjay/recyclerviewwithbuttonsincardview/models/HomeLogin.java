package com.dhananjay.recyclerviewwithbuttonsincardview.models;

import com.google.gson.annotations.SerializedName;

public class HomeLogin {

    @SerializedName("uuid")
    private String uuid;

    public String getUuid() {
        return uuid;
    }
}
