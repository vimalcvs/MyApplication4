package com.dhananjay.recyclerviewwithbuttonsincardview.app;

import com.dhananjay.recyclerviewwithbuttonsincardview.models.HomeResult;

public interface HomeOnRecordEventListener {

    void accept(HomeResult homeResult);

    void decline(HomeResult homeResult);
}
