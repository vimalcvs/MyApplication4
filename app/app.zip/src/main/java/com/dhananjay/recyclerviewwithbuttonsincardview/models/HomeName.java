package com.dhananjay.recyclerviewwithbuttonsincardview.models;

import com.google.gson.annotations.SerializedName;

public class HomeName {

    @SerializedName("first")
    private String first;

    public String getFirst() {
        return first;
    }
}
