package com.dhananjay.recyclerviewwithbuttonsincardview.app;

public class HomeConstants {

    public static final int PENDING = 0;
    public static final int ACCEPT = 1;
    public static final int DECLINE = 2;

}
