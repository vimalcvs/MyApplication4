package com.dhananjay.recyclerviewwithbuttonsincardview.models;

import com.google.gson.annotations.SerializedName;

public class HomePicture {

    @SerializedName("thumbnail")
    private String thumbnail;

    public String getThumbnail() {
        return thumbnail;
    }

}
